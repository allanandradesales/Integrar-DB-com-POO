INSERT INTO Usuario (nome, email, senha, perfil) VALUES
('Allan Sales', 'allan@checkin.com', SHA2('123456', 256), 'participante');
